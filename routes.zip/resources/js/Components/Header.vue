<script setup>
import { ref } from 'vue'

const mobileOpen = ref(false)

const toggleMobile = () => {
    mobileOpen.value = !mobileOpen.value
}
</script>

<template>
    <header class="sticky top-0 z-50 bg-heritage-navy text-white shadow-lg">

        <div class="mx-auto flex h-[74px] max-w-[1400px] items-center justify-between px-5 lg:px-8">

            <!-- Logo -->
            <a href="/" class="flex shrink-0 items-center">
                <div class="flex items-center gap-3">
                    <div class="flex h-11 w-11 items-center justify-center bg-heritage-gold text-heritage-navy">
                        <span class="font-display text-2xl font-bold">H</span>
                    </div>

                    <div class="leading-none">
                        <div class="font-display text-xl font-semibold">
                            Heritage
                        </div>

                        <div class="mt-1 text-[9px] font-semibold tracking-[0.18em] text-white/80">
                            CAPITAL MARKETS
                        </div>
                    </div>
                </div>
            </a>

            <!-- Desktop Navigation -->
            <nav class="hidden items-center gap-7 lg:flex">

                <a
                    href="/"
                    class="relative py-7 text-sm font-medium transition hover:text-heritage-gold"
                >
                    Home
                    <span class="absolute bottom-0 left-0 h-[3px] w-full bg-heritage-gold"></span>
                </a>

                <a
                    href="/about-us"
                    class="py-7 text-sm font-medium transition hover:text-heritage-gold"
                >
                    About Us
                </a>

                <div class="group relative">
                    <button
                        class="flex items-center gap-1 py-7 text-sm font-medium hover:text-heritage-gold"
                    >
                        Investment Solutions
                        <svg
                            class="h-3.5 w-3.5"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                        >
                            <path
                                fill-rule="evenodd"
                                d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.51a.75.75 0 01-1.08 0l-4.25-4.51a.75.75 0 01.02-1.06z"
                                clip-rule="evenodd"
                            />
                        </svg>
                    </button>

                    <div class="invisible absolute left-0 top-full w-64 translate-y-2 rounded-b-md bg-white py-3 text-heritage-text opacity-0 shadow-xl transition-all group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">

                        <a href="/investment-solutions" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            Investment Solutions
                        </a>

                        <a href="/investment-solutions/portfolio-management" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            Portfolio Management
                        </a>

                        <a href="/investment-solutions/investment-advisory" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            Investment Advisory
                        </a>

                        <a href="/investment-solutions/brokerage" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            Brokerage & Dealing
                        </a>

                        <a href="/investment-solutions/fixed-income" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            Fixed Income
                        </a>

                        <a href="/investment-solutions/alternative-investments" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            Alternative Investments
                        </a>

                        <a href="/investment-solutions/financial-planning" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            Financial Planning
                        </a>

                    </div>
                </div>

                <div class="group relative">
                    <button class="flex items-center gap-1 py-7 text-sm font-medium hover:text-heritage-gold">
                        Research Centre

                        <svg
                            class="h-3.5 w-3.5"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                        >
                            <path
                                fill-rule="evenodd"
                                d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.51a.75.75 0 01-1.08 1.04l-4.25 4.51a.75.75 0 01-1.06.02.75.75 0 01-.02-1.06z"
                                clip-rule="evenodd"
                            />
                        </svg>
                    </button>

                    <div class="invisible absolute left-0 top-full w-56 translate-y-2 rounded-b-md bg-white py-3 text-heritage-text opacity-0 shadow-xl transition-all group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">

                        <a href="/research-centre" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            Research Centre
                        </a>

                        <a href="/research-centre/market-overview" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            Market Overview
                        </a>

                        <a href="/research-centre/reports" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            Research Reports
                        </a>

                    </div>
                </div>

                <div class="group relative">
                    <button class="flex items-center gap-1 py-7 text-sm font-medium hover:text-heritage-gold">
                        Resources

                        <svg
                            class="h-3.5 w-3.5"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                        >
                            <path
                                fill-rule="evenodd"
                                d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.51a.75.75 0 01-1.08 1.04l-4.25-4.51a.75.75 0 01-1.06.02.75.75 0 01-.02-1.06z"
                                clip-rule="evenodd"
                            />
                        </svg>
                    </button>

                    <div class="invisible absolute left-0 top-full w-52 translate-y-2 rounded-b-md bg-white py-3 text-heritage-text opacity-0 shadow-xl transition-all group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">

                        <a href="/resources" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            News & Insights
                        </a>

                        <a href="/resources/downloads" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            Downloads
                        </a>

                        <a href="/resources/faqs" class="block px-5 py-2.5 text-sm hover:bg-gray-50 hover:text-heritage-gold">
                            FAQs
                        </a>

                    </div>
                </div>

                <a
                    href="/contact-us"
                    class="py-7 text-sm font-medium transition hover:text-heritage-gold"
                >
                    Contact Us
                </a>

            </nav>

            <!-- Right Actions -->
            <div class="hidden items-center gap-3 lg:flex">

                <!-- Search -->
                <button
                    class="flex h-10 w-10 items-center justify-center rounded-full hover:bg-white/10"
                    aria-label="Search"
                >
                    <svg
                        class="h-5 w-5"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                        viewBox="0 0 24 24"
                    >
                        <circle cx="11" cy="11" r="7"></circle>
                        <path d="m20 20-4-4"></path>
                    </svg>
                </button>

                <!-- Open Account -->
                <a
                    href="/open-account"
                    class="rounded border border-heritage-gold px-5 py-2.5 text-sm font-semibold transition hover:bg-heritage-gold hover:text-heritage-navy"
                >
                    Open an Account
                </a>

                <!-- Investor Login -->
                <a
                    href="/investor-login"
                    class="flex items-center gap-2 rounded bg-heritage-gold px-5 py-2.5 text-sm font-semibold text-heritage-navy transition hover:bg-heritage-gold-light"
                >
                    <svg
                        class="h-4 w-4"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                        viewBox="0 0 24 24"
                    >
                        <circle cx="12" cy="8" r="3.5"></circle>
                        <path d="M5 20c.8-3.2 3.2-5 7-5s6.2 1.8 7 5"></path>
                    </svg>

                    Investor Login
                </a>

            </div>

            <!-- Mobile Button -->
            <button
                @click="toggleMobile"
                class="flex h-10 w-10 items-center justify-center rounded border border-white/20 lg:hidden"
                aria-label="Open menu"
            >
                <svg
                    v-if="!mobileOpen"
                    class="h-6 w-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                >
                    <path stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                </svg>

                <svg
                    v-else
                    class="h-6 w-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                >
                    <path stroke-width="2" d="M6 6l12 12M6 18L18 6"/>
                </svg>
            </button>

        </div>

        <!-- Mobile Navigation -->
        <div
            v-if="mobileOpen"
            class="border-t border-white/10 bg-heritage-deep px-5 py-5 lg:hidden"
        >
            <div class="space-y-1">

                <a href="/" class="block rounded px-3 py-3 hover:bg-white/5">
                    Home
                </a>

                <a href="/about-us" class="block rounded px-3 py-3 hover:bg-white/5">
                    About Us
                </a>

                <a href="/investment-solutions" class="block rounded px-3 py-3 hover:bg-white/5">
                    Investment Solutions
                </a>

                <a href="/research-centre" class="block rounded px-3 py-3 hover:bg-white/5">
                    Research Centre
                </a>

                <a href="/resources" class="block rounded px-3 py-3 hover:bg-white/5">
                    Resources
                </a>

                <a href="/contact-us" class="block rounded px-3 py-3 hover:bg-white/5">
                    Contact Us
                </a>

                <div class="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">

                    <a
                        href="/open-account"
                        class="rounded border border-heritage-gold px-4 py-3 text-center font-semibold"
                    >
                        Open an Account
                    </a>

                    <a
                        href="/investor-login"
                        class="rounded bg-heritage-gold px-4 py-3 text-center font-semibold text-heritage-navy"
                    >
                        Investor Login
                    </a>

                </div>

            </div>
        </div>

    </header>
</template>