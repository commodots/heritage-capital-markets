<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import PublicLayout from '@/Layouts/PublicLayout.vue'
import Button from '@/Components/Button.vue'

const currentSlide = ref(0)
let timer = null

const slides = [
    {
        image: '/images/hero/slide-01-coins-tree.webp',
        eyebrow: 'BUILDING WEALTH. CREATING VALUE.',
        title: 'Your Trusted Partner in Investment Excellence.',
        description:
            'Innovative investment solutions, market expertise and a commitment to your financial future.',
        primary: 'Explore Our Solutions',
        primaryHref: '/investment-solutions',
        secondary: 'Open an Account',
        secondaryHref: '/open-account',
        location: 'The Heritage Place',
    },
    {
        image: '/images/hero/slide-02-market-insights.webp',
        eyebrow: 'INSIGHTS THAT MATTER.',
        title: 'Turning Insight Into Opportunity.',
        description:
            'Access expert analysis, market intelligence and actionable insights to stay ahead.',
        primary: 'View Market Insights',
        primaryHref: '/research-centre/market-overview',
        secondary: 'Research Reports',
        secondaryHref: '/research-centre/reports',
        location: 'Market Intelligence',
    },
    {
        image: '/images/hero/slide-03-heritage-reception.webp',
        eyebrow: 'A LEGACY OF TRUST.',
        title: 'Partnering for Progress.',
        description:
            'Backed by experience, driven by innovation and committed to your success.',
        primary: 'About Us',
        primaryHref: '/about-us',
        secondary: 'Our Commitment',
        secondaryHref: '/about-us',
        location: 'The Heritage Place',
    },
    {
        image: '/images/hero/slide-04-financial-future.webp',
        eyebrow: 'YOUR GOALS. OUR COMMITMENT.',
        title: 'A More Secure Financial Tomorrow.',
        description:
            'Personalised investment solutions to help you achieve what matters most.',
        primary: 'Open an Account',
        primaryHref: '/open-account',
        secondary: 'Speak to an Advisor',
        secondaryHref: '/contact-us',
        location: 'Your Financial Future',
    },
]

const slide = computed(() => slides[currentSlide.value])

function nextSlide() {
    currentSlide.value = (currentSlide.value + 1) % slides.length
}

function previousSlide() {
    currentSlide.value =
        (currentSlide.value - 1 + slides.length) % slides.length
}

function goToSlide(index) {
    currentSlide.value = index
}

function startCarousel() {
    timer = setInterval(nextSlide, 7000)
}

function stopCarousel() {
    if (timer) {
        clearInterval(timer)
        timer = null
    }
}

onMounted(startCarousel)
onBeforeUnmount(stopCarousel)
</script>

<template>
    <PublicLayout>

        <!-- HERO -->
        <section
            class="relative min-h-[620px] overflow-hidden bg-heritage-deep text-white lg:min-h-[690px]"
            @mouseenter="stopCarousel"
            @mouseleave="startCarousel"
        >

            <!-- Background -->
            <Transition
                enter-active-class="transition-opacity duration-700"
                enter-from-class="opacity-0"
                enter-to-class="opacity-100"
                leave-active-class="absolute inset-0 transition-opacity duration-700"
                leave-from-class="opacity-100"
                leave-to-class="opacity-0"
            >
                <div
                    :key="currentSlide"
                    class="absolute inset-0 bg-cover bg-center"
                    :style="{
                        backgroundImage: `url('${slide.image}')`
                    }"
                ></div>
            </Transition>

            <!-- Dark fintech overlay -->
            <div
                class="absolute inset-0 bg-gradient-to-r from-[#031426] via-[#031426]/85 to-[#031426]/20"
            ></div>

            <!-- Bottom image darkening -->
            <div
                class="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-[#031426]/80 to-transparent"
            ></div>

            <!-- Decorative pattern -->
            <div class="absolute inset-y-0 left-0 hidden w-1/3 opacity-20 lg:block">
                <div class="absolute -left-28 top-20 h-[500px] w-[500px] rounded-full border border-heritage-gold"></div>
                <div class="absolute -left-20 top-28 h-[420px] w-[420px] rounded-full border border-heritage-gold"></div>
                <div class="absolute -left-12 top-36 h-[340px] w-[340px] rounded-full border border-heritage-gold"></div>
            </div>

            <!-- Hero Content -->
            <div class="relative z-10 mx-auto flex min-h-[620px] max-w-[1400px] items-center px-6 py-24 lg:min-h-[690px] lg:px-12">

                <div class="max-w-[650px] pl-12 lg:pl-20 xl:pl-24">

                    <!-- Slide indicator -->
                    <div class="mb-5 flex items-center gap-3 text-xs font-semibold tracking-[0.25em] text-white/80">
                        <span>
                            {{ String(currentSlide + 1).padStart(2, '0') }}
                        </span>

                        <span>/</span>

                        <span>04</span>

                        <span class="h-px w-10 bg-heritage-gold"></span>

                        <span class="text-heritage-gold">
                            {{ slide.eyebrow }}
                        </span>
                    </div>

                    <!-- Heading -->
                    <h1
                        class="font-display text-5xl leading-[0.98] tracking-tight text-white sm:text-6xl lg:text-[76px]"
                    >
                        <span
                            v-if="currentSlide === 0"
                        >
                            Your Trusted<br>
                            Partner in<br>
                            <span class="text-heritage-gold">
                                Investment<br class="hidden sm:block">
                                Excellence.
                            </span>
                        </span>

                        <span v-else>
                            {{ slide.title }}
                        </span>
                    </h1>

                    <!-- Description -->
                    <p class="mt-7 max-w-xl text-base leading-7 text-white/85 lg:text-lg">
                        {{ slide.description }}
                    </p>

                    <!-- Buttons -->
                    <div class="mt-8 flex flex-wrap gap-3">

                        <Button
                            :href="slide.primaryHref"
                            variant="gold"
                        >
                            {{ slide.primary }}
                            <span>→</span>
                        </Button>

                        <Button
                            :href="slide.secondaryHref"
                            variant="outline"
                        >
                            {{ slide.secondary }}
                            <span>→</span>
                        </Button>

                    </div>

                </div>

                <!-- Location / slide label -->
                <div class="absolute bottom-20 right-8 hidden rounded-lg border border-white/20 bg-heritage-deep/70 px-5 py-4 backdrop-blur-md lg:block">

                    <div class="flex items-center gap-3">

                        <div class="flex h-9 w-9 items-center justify-center rounded-full border border-heritage-gold text-heritage-gold">
                            <svg
                                class="h-5 w-5"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="1.6"
                                    d="M12 21s7-5.2 7-11a7 7 0 1 0-14 0c0 5.8 7 11 7 11Z"
                                />
                                <circle cx="12" cy="10" r="2.5" />
                            </svg>
                        </div>

                        <div>
                            <div class="text-xs text-white/60">
                                Heritage
                            </div>

                            <div class="text-sm font-medium">
                                {{ slide.location }}
                            </div>
                        </div>

                    </div>

                </div>

            </div>

            <!-- Previous -->
            <button
                type="button"
                @click="previousSlide"
                class="absolute left-5 top-1/2 z-20 hidden h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-white/20 bg-heritage-deep/50 text-white backdrop-blur-sm transition hover:border-heritage-gold hover:text-heritage-gold lg:flex"
                aria-label="Previous slide"
            >
                ←
            </button>

            <!-- Next -->
            <button
                type="button"
                @click="nextSlide"
                class="absolute right-5 top-1/2 z-20 hidden h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-white/20 bg-heritage-deep/50 text-white backdrop-blur-sm transition hover:border-heritage-gold hover:text-heritage-gold lg:flex"
                aria-label="Next slide"
            >
                →
            </button>

            <!-- Dots -->
            <div class="absolute bottom-7 left-1/2 z-20 flex -translate-x-1/2 gap-2">

                <button
                    v-for="(_, index) in slides"
                    :key="index"
                    type="button"
                    @click="goToSlide(index)"
                    class="h-1.5 rounded-full transition-all duration-300"
                    :class="
                        index === currentSlide
                            ? 'w-10 bg-heritage-gold'
                            : 'w-5 bg-white/40 hover:bg-white/70'
                    "
                    :aria-label="`Go to slide ${index + 1}`"
                ></button>

            </div>

        </section>


        <!-- TRUST / CREDIBILITY STRIP -->
<section class="relative z-20 bg-heritage-navy text-white">
    <div class="mx-auto max-w-[1400px] px-6 lg:px-12">

        <div class="grid grid-cols-1 divide-y divide-white/10 sm:grid-cols-2 sm:divide-x sm:divide-y-0 lg:grid-cols-4">

            <!-- 30+ Years -->
            <div class="flex items-center gap-4 px-4 py-6 lg:px-7">
                <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-heritage-gold/60 text-heritage-gold">
                    <svg
                        class="h-6 w-6"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="1.6"
                            d="M12 3l2.2 4.5L19 8.2l-3.5 3.4.8 4.8L12 14.1 7.7 16.4l.8-4.8L5 8.2l4.8-.7L12 3Z"
                        />
                        <path
                            stroke-linecap="round"
                            stroke-width="1.6"
                            d="M8 20h8"
                        />
                    </svg>
                </div>

                <div>
                    <h3 class="font-display text-base font-semibold lg:text-lg">
                        30+ Years
                    </h3>

                    <p class="mt-0.5 text-xs text-white/60">
                        Market Experience
                    </p>
                </div>
            </div>


            <!-- Client Focused -->
            <div class="flex items-center gap-4 px-4 py-6 lg:px-7">
                <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-heritage-gold/60 text-heritage-gold">
                    <svg
                        class="h-6 w-6"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <circle
                            cx="9"
                            cy="8"
                            r="3"
                            stroke-width="1.6"
                        />
                        <circle
                            cx="17"
                            cy="9"
                            r="2.3"
                            stroke-width="1.6"
                        />
                        <path
                            stroke-linecap="round"
                            stroke-width="1.6"
                            d="M3.5 20c.5-3.5 2.5-5.5 5.5-5.5s5 2 5.5 5.5"
                        />
                        <path
                            stroke-linecap="round"
                            stroke-width="1.6"
                            d="M14 15c3.2-.5 5.5 1.2 6.2 4.5"
                        />
                    </svg>
                </div>

                <div>
                    <h3 class="font-display text-base font-semibold lg:text-lg">
                        Client Focused
                    </h3>

                    <p class="mt-0.5 text-xs text-white/60">
                        Individual &amp; Corporate
                    </p>
                </div>
            </div>


            <!-- SEC Regulated -->
            <div class="flex items-center gap-4 px-4 py-6 lg:px-7">
                <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-heritage-gold/60 text-heritage-gold">
                    <svg
                        class="h-6 w-6"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            stroke-linejoin="round"
                            stroke-width="1.6"
                            d="M4 20h16M6 20V9h12v11M9 9V5h6v4M3 9h18"
                        />
                        <path
                            stroke-linecap="round"
                            stroke-width="1.6"
                            d="M9 13h.01M12 13h.01M15 13h.01M9 16h.01M12 16h.01M15 16h.01"
                        />
                    </svg>
                </div>

                <div>
                    <h3 class="font-display text-base font-semibold lg:text-lg">
                        SEC Regulated
                    </h3>

                    <p class="mt-0.5 text-xs text-white/60">
                        Trusted &amp; Compliant
                    </p>
                </div>
            </div>


            <!-- Research Driven -->
            <div class="flex items-center gap-4 px-4 py-6 lg:px-7">
                <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-heritage-gold/60 text-heritage-gold">
                    <svg
                        class="h-6 w-6"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="1.6"
                            d="M4 19V5M4 19h16"
                        />
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="1.6"
                            d="M7 15l3-4 3 2 5-6"
                        />
                        <circle
                            cx="7"
                            cy="15"
                            r="1"
                            fill="currentColor"
                            stroke="none"
                        />
                        <circle
                            cx="10"
                            cy="11"
                            r="1"
                            fill="currentColor"
                            stroke="none"
                        />
                        <circle
                            cx="13"
                            cy="13"
                            r="1"
                            fill="currentColor"
                            stroke="none"
                        />
                        <circle
                            cx="18"
                            cy="7"
                            r="1"
                            fill="currentColor"
                            stroke="none"
                        />
                    </svg>
                </div>

                <div>
                    <h3 class="font-display text-base font-semibold lg:text-lg">
                        Research Driven
                    </h3>

                    <p class="mt-0.5 text-xs text-white/60">
                        Insights That Matter
                    </p>
                </div>
            </div>

        </div>

    </div>
</section>


        <!-- MARKET OVERVIEW -->
        <section class="border-b border-heritage-border bg-white">

            <div class="mx-auto max-w-[1400px] px-6 py-7 lg:px-12">

                <div class="grid gap-5 lg:grid-cols-[220px_1fr] lg:items-center">

                    <div>
                        <div class="text-xs font-semibold uppercase tracking-[0.2em] text-heritage-gold">
                            Market Overview
                        </div>

                        <h2 class="mt-1 font-display text-2xl text-heritage-navy">
                            Today's Markets
                        </h2>
                    </div>

                    <div class="grid grid-cols-2 gap-4 md:grid-cols-5">

                        <div
                            v-for="market in [
                                ['NGX All-Share', '102,026.75', '+0.63%'],
                                ['NGX 30', '3,938.85', '+0.41%'],
                                ['Banking', '1,205.67', '+0.75%'],
                                ['Industrial Goods', '4,182.11', '-0.28%'],
                                ['Oil & Gas', '2,216.36', '+0.31%']
                            ]"
                            :key="market[0]"
                            class="border-l border-heritage-border pl-4"
                        >
                            <div class="text-xs text-heritage-muted">
                                {{ market[0] }}
                            </div>

                            <div class="mt-1 font-semibold text-heritage-navy">
                                {{ market[1] }}
                            </div>

                            <div
                                class="text-xs font-semibold"
                                :class="market[2].startsWith('-')
                                    ? 'text-red-500'
                                    : 'text-green-600'"
                            >
                                ▲ {{ market[2] }}
                            </div>
                        </div>

                    </div>

                </div>

            </div>

        </section>


        <!-- SOLUTIONS -->
        <section class="bg-heritage-offwhite">

            <div class="mx-auto max-w-[1400px] px-6 py-16 lg:px-12">

                <div class="grid gap-10 lg:grid-cols-[300px_1fr]">

                    <div>

                        <div class="text-xs font-semibold uppercase tracking-[0.2em] text-heritage-gold">
                            Invest With Confidence
                        </div>

                        <h2 class="mt-3 font-display text-4xl leading-tight text-heritage-navy">
                            Solutions for Today.<br>
                            A Stronger Tomorrow.
                        </h2>

                        <p class="mt-5 text-sm leading-6 text-heritage-muted">
                            From wealth management to capital markets advisory,
                            we provide tailored solutions to help you grow,
                            protect and manage your wealth.
                        </p>

                        <a
                            href="/investment-solutions"
                            class="mt-7 inline-flex items-center gap-2 rounded bg-heritage-gold px-6 py-3 text-sm font-semibold text-heritage-deep"
                        >
                            Discover Our Solutions
                            <span>→</span>
                        </a>

                    </div>


                    <div class="grid gap-5 md:grid-cols-3">

                        <article
                            v-for="item in [
                                {
                                    title: 'Wealth Creation',
                                    text: 'Strategic investment solutions designed around your goals.',
                                    image: '/images/hero/slide-01-coins-tree.webp'
                                },
                                {
                                    title: 'Expert Guidance',
                                    text: 'A dedicated team with deep market knowledge.',
                                    image: '/images/hero/slide-02-market-insights.webp'
                                },
                                {
                                    title: 'A More Secure Future',
                                    text: 'Helping you build and preserve wealth for generations.',
                                    image: '/images/hero/slide-04-financial-future.webp'
                                }
                            ]"
                            :key="item.title"
                            class="overflow-hidden rounded-lg bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
                        >

                            <img
                                :src="item.image"
                                :alt="item.title"
                                class="h-48 w-full object-cover"
                            >

                            <div class="p-6">

                                <h3 class="font-display text-xl text-heritage-navy">
                                    {{ item.title }}
                                </h3>

                                <p class="mt-2 text-sm leading-6 text-heritage-muted">
                                    {{ item.text }}
                                </p>

                                <a
                                    href="/investment-solutions"
                                    class="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-heritage-gold"
                                >
                                    Learn More →
                                </a>

                            </div>

                        </article>

                    </div>

                </div>

            </div>

        </section>
		<!-- WHY HERITAGE -->
<section class="bg-white">
    <div class="mx-auto max-w-[1400px] px-6 py-20 lg:px-12">

        <!-- Section heading -->
        <div class="max-w-3xl">
            <div class="text-xs font-semibold uppercase tracking-[0.22em] text-heritage-gold">
                Why Heritage
            </div>

            <h2 class="mt-3 font-display text-4xl leading-tight text-heritage-navy sm:text-5xl">
                Experience You Can Trust.<br>
                Expertise That Delivers.
            </h2>

            <p class="mt-5 max-w-2xl text-base leading-7 text-heritage-muted">
                We combine deep market knowledge, disciplined investment
                processes and a client-focused approach to help individuals,
                businesses and institutions pursue their financial objectives.
            </p>
        </div>


        <!-- Main content -->
        <div class="mt-12 grid gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:items-stretch">

            <!-- Image -->
            <div class="relative min-h-[460px] overflow-hidden rounded-xl">

                <img
                    src="/images/hero/slide-03-heritage-reception.webp"
                    alt="Heritage Capital Markets"
                    class="absolute inset-0 h-full w-full object-cover"
                >

                <!-- Overlay -->
                <div class="absolute inset-0 bg-gradient-to-t from-heritage-deep/90 via-heritage-deep/10 to-transparent"></div>

                <!-- Image caption -->
                <div class="absolute bottom-0 left-0 right-0 p-7 text-white">

                    <div class="text-xs font-semibold uppercase tracking-[0.2em] text-heritage-gold">
                        The Heritage Difference
                    </div>

                    <h3 class="mt-2 font-display text-3xl">
                        Built Around Your Goals.
                    </h3>

                    <p class="mt-2 max-w-lg text-sm leading-6 text-white/75">
                        Trusted relationships, informed decisions and
                        investment solutions designed with your future in mind.
                    </p>

                </div>
            </div>


            <!-- Benefits -->
            <div class="grid gap-4 sm:grid-cols-2">

                <!-- Experience -->
                <div class="rounded-xl border border-heritage-border bg-heritage-offwhite p-7 transition hover:-translate-y-1 hover:shadow-lg">

                    <div class="flex h-12 w-12 items-center justify-center rounded-full border border-heritage-gold/60 text-heritage-gold">

                        <svg
                            class="h-6 w-6"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="1.6"
                                d="M12 3l2.2 4.5L19 8.2l-3.5 3.4.8 4.8L12 14.1 7.7 16.4l.8-4.8L5 8.2l4.8-.7L12 3Z"
                            />
                            <path
                                stroke-linecap="round"
                                stroke-width="1.6"
                                d="M8 20h8"
                            />
                        </svg>

                    </div>

                    <h3 class="mt-6 font-display text-2xl text-heritage-navy">
                        Proven Experience
                    </h3>

                    <p class="mt-3 text-sm leading-6 text-heritage-muted">
                        Decades of experience in Nigeria's capital markets
                        and a deep understanding of evolving market conditions.
                    </p>

                </div>


                <!-- Client Focus -->
                <div class="rounded-xl border border-heritage-border bg-heritage-offwhite p-7 transition hover:-translate-y-1 hover:shadow-lg">

                    <div class="flex h-12 w-12 items-center justify-center rounded-full border border-heritage-gold/60 text-heritage-gold">

                        <svg
                            class="h-6 w-6"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <circle
                                cx="9"
                                cy="8"
                                r="3"
                                stroke-width="1.6"
                            />
                            <circle
                                cx="17"
                                cy="9"
                                r="2.3"
                                stroke-width="1.6"
                            />
                            <path
                                stroke-linecap="round"
                                stroke-width="1.6"
                                d="M3.5 20c.5-3.5 2.5-5.5 5.5-5.5s5 2 5.5 5.5"
                            />
                            <path
                                stroke-linecap="round"
                                stroke-width="1.6"
                                d="M14 15c3.2-.5 5.5 1.2 6.2 4.5"
                            />
                        </svg>

                    </div>

                    <h3 class="mt-6 font-display text-2xl text-heritage-navy">
                        Client Focused
                    </h3>

                    <p class="mt-3 text-sm leading-6 text-heritage-muted">
                        We put your objectives, preferences and long-term
                        financial goals at the centre of every engagement.
                    </p>

                </div>


                <!-- Market Expertise -->
                <div class="rounded-xl border border-heritage-border bg-heritage-offwhite p-7 transition hover:-translate-y-1 hover:shadow-lg">

                    <div class="flex h-12 w-12 items-center justify-center rounded-full border border-heritage-gold/60 text-heritage-gold">

                        <svg
                            class="h-6 w-6"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="1.6"
                                d="M4 19V5M4 19h16"
                            />

                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="1.6"
                                d="M7 15l3-4 3 2 5-6"
                            />

                            <circle cx="18" cy="7" r="1" fill="currentColor" />
                        </svg>

                    </div>

                    <h3 class="mt-6 font-display text-2xl text-heritage-navy">
                        Market Expertise
                    </h3>

                    <p class="mt-3 text-sm leading-6 text-heritage-muted">
                        Research-driven insights and market intelligence
                        support informed investment decisions.
                    </p>

                </div>


                <!-- Transparency -->
                <div class="rounded-xl border border-heritage-border bg-heritage-offwhite p-7 transition hover:-translate-y-1 hover:shadow-lg">

                    <div class="flex h-12 w-12 items-center justify-center rounded-full border border-heritage-gold/60 text-heritage-gold">

                        <svg
                            class="h-6 w-6"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="1.6"
                                d="M12 3l7 3v5c0 4.5-2.9 8.3-7 10-4.1-1.7-7-5.5-7-10V6l7-3Z"
                            />

                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="1.6"
                                d="m9 12 2 2 4-4"
                            />
                        </svg>

                    </div>

                    <h3 class="mt-6 font-display text-2xl text-heritage-navy">
                        Trust &amp; Transparency
                    </h3>

                    <p class="mt-3 text-sm leading-6 text-heritage-muted">
                        Clear communication, disciplined processes and a
                        strong commitment to professional standards.
                    </p>

                </div>

            </div>

        </div>


        <!-- Bottom metrics -->
        <div class="mt-10 grid grid-cols-2 border-y border-heritage-border md:grid-cols-4">

            <div class="border-b border-heritage-border px-6 py-7 text-center md:border-b-0 md:border-r">
                <div class="font-display text-3xl text-heritage-navy">
                    30+
                </div>

                <div class="mt-1 text-xs uppercase tracking-wider text-heritage-muted">
                    Years Experience
                </div>
            </div>

            <div class="border-b border-heritage-border px-6 py-7 text-center md:border-b-0 md:border-r">
                <div class="font-display text-3xl text-heritage-navy">
                    100+
                </div>

                <div class="mt-1 text-xs uppercase tracking-wider text-heritage-muted">
                    Clients Served
                </div>
            </div>

            <div class="border-r border-heritage-border px-6 py-7 text-center">
                <div class="font-display text-3xl text-heritage-navy">
                    ₦850B+
                </div>

                <div class="mt-1 text-xs uppercase tracking-wider text-heritage-muted">
                    Assets Under Management
                </div>
            </div>

            <div class="px-6 py-7 text-center">
                <div class="font-display text-3xl text-heritage-navy">
                    120+
                </div>

                <div class="mt-1 text-xs uppercase tracking-wider text-heritage-muted">
                    Dedicated Professionals
                </div>
            </div>

        </div>

    </div>
</section>

    </PublicLayout>
</template>